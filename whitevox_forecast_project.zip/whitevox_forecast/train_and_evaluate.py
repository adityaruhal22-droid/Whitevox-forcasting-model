import warnings
warnings.filterwarnings("ignore")

import joblib
import numpy as np
import pandas as pd
from xgboost import XGBRegressor
from statsmodels.tsa.statespace.sarimax import SARIMAX

import forecasting_lib as flib

ARTIFACT_DIR = "artifacts"

# ---------------------------------------------------------------------------
# 1. Load data
# ---------------------------------------------------------------------------
df_company = flib.load_company_df()
df_service = flib.load_service_df()
print("Company rows:", df_company.shape, "| Service rows:", df_service.shape)

# ---------------------------------------------------------------------------
# 2. Company-level: fit trend on TRAIN portion only, build features, split
# ---------------------------------------------------------------------------
train_only_c, _ = flib.time_split(df_company, flib.HOLDOUT_MONTHS)
company_trend = flib.fit_trend(
    np.arange(len(train_only_c)), train_only_c[flib.COMPANY_TARGET_COL].to_numpy()
)

feat_company = flib.build_company_features(df_company, company_trend)
feat_company_model = feat_company.dropna(subset=flib.COMPANY_FEATURE_COLS).reset_index(drop=True)
train_c, test_c = flib.time_split(feat_company_model, flib.HOLDOUT_MONTHS)
print("Company train/test:", train_c.shape, test_c.shape)

X_train_c, y_train_c = train_c[flib.COMPANY_FEATURE_COLS], train_c[flib.COMPANY_RESID_COL]
X_test_c, y_test_c = test_c[flib.COMPANY_FEATURE_COLS], test_c[flib.COMPANY_RESID_COL]

# --- Baseline: seasonal naive (on the actual revenue series) ---
naive_pred = flib.seasonal_naive_forecast(feat_company_model[flib.COMPANY_TARGET_COL], flib.HOLDOUT_MONTHS)
naive_metrics = flib.regression_metrics(test_c[flib.COMPANY_TARGET_COL], naive_pred)
print("Seasonal naive:", naive_metrics)

# --- Classical: SARIMAX on total_revenue_usd ---
train_series = feat_company_model.iloc[:-flib.HOLDOUT_MONTHS][flib.COMPANY_TARGET_COL]
sarimax_model = SARIMAX(
    train_series, order=(1, 1, 1), seasonal_order=(1, 1, 0, 12),
    enforce_stationarity=False, enforce_invertibility=False,
).fit(disp=False)
sarimax_pred = sarimax_model.forecast(flib.HOLDOUT_MONTHS).to_numpy()
sarimax_metrics = flib.regression_metrics(test_c[flib.COMPANY_TARGET_COL], sarimax_pred)
print("SARIMAX:", sarimax_metrics)

# --- ML: XGBoost on trend-residual features ---
xgb_company = XGBRegressor(
    n_estimators=300, max_depth=3, learning_rate=0.05,
    subsample=0.8, colsample_bytree=0.8, random_state=42,
)
xgb_company.fit(X_train_c, y_train_c)
resid_pred = xgb_company.predict(X_test_c)
xgb_revenue_pred = np.expm1(test_c["trend_log"].to_numpy() + resid_pred)
xgb_metrics = flib.regression_metrics(test_c[flib.COMPANY_TARGET_COL], xgb_revenue_pred)
print("XGBoost (trend + residual):", xgb_metrics)

comparison = pd.DataFrame(
    [naive_metrics, sarimax_metrics, xgb_metrics],
    index=["Seasonal Naive", "SARIMAX", "XGBoost (trend+residual)"],
)
print("\nModel comparison (12-month holdout, actual $ revenue):\n", comparison)

winner = comparison["MAPE_%"].idxmin()
print("\nWinning model by MAPE:", winner)

# ---------------------------------------------------------------------------
# 3. Refit trend + XGBoost on ALL data for deployment
# ---------------------------------------------------------------------------
company_trend_final = flib.fit_trend(
    np.arange(len(df_company)), df_company[flib.COMPANY_TARGET_COL].to_numpy()
)
feat_company_final = flib.build_company_features(df_company, company_trend_final)
feat_company_final_model = feat_company_final.dropna(subset=flib.COMPANY_FEATURE_COLS).reset_index(drop=True)

xgb_company_final = XGBRegressor(
    n_estimators=300, max_depth=3, learning_rate=0.05,
    subsample=0.8, colsample_bytree=0.8, random_state=42,
)
xgb_company_final.fit(
    feat_company_final_model[flib.COMPANY_FEATURE_COLS], feat_company_final_model[flib.COMPANY_RESID_COL]
)

# ---------------------------------------------------------------------------
# 4. Service-line-level: fit per-line trend on TRAIN portion, build features, split
# ---------------------------------------------------------------------------
df_service_post = flib.restrict_to_post_launch(df_service)
service_trends = flib.fit_service_trends(df_service_post, flib.HOLDOUT_MONTHS)
feat_service = flib.build_service_features(df_service, service_trends)
train_s, test_s = flib.time_split_panel(feat_service, flib.HOLDOUT_MONTHS)
print("\nService train/test:", train_s.shape, test_s.shape)

X_train_s, y_train_s = train_s[flib.SERVICE_FEATURE_COLS], train_s[flib.SERVICE_RESID_COL]
X_test_s, y_test_s = test_s[flib.SERVICE_FEATURE_COLS], test_s[flib.SERVICE_RESID_COL]

xgb_service = XGBRegressor(
    n_estimators=400, max_depth=4, learning_rate=0.05,
    subsample=0.8, colsample_bytree=0.8, random_state=42,
    enable_categorical=True, tree_method="hist",
)
xgb_service.fit(X_train_s, y_train_s)
service_resid_pred = xgb_service.predict(X_test_s)
service_revenue_pred = np.expm1(np.log1p(test_s[flib.SERVICE_TARGET_COL]) - test_s[flib.SERVICE_RESID_COL] + service_resid_pred)
# (test_s["resid"] = log1p(rev) - trend_log  =>  trend_log = log1p(rev) - resid)
service_metrics = flib.regression_metrics(test_s[flib.SERVICE_TARGET_COL], service_revenue_pred)
print("XGBoost (per service line):", service_metrics)

# Reconcile: does summing per-line predictions approximate the company total?
test_s_pred_df = test_s[["date", "service_line"]].copy()
test_s_pred_df["pred"] = service_revenue_pred
recon = test_s_pred_df.groupby("date", observed=True)["pred"].sum().reset_index()
recon = recon.merge(test_c[["date", flib.COMPANY_TARGET_COL]], on="date", how="inner")
recon_metrics = flib.regression_metrics(recon[flib.COMPANY_TARGET_COL], recon["pred"])
print("Reconciliation (sum of per-line preds vs company total):", recon_metrics)

# Refit trend + XGBoost on ALL data for deployment
service_trends_final = flib.fit_service_trends(df_service_post, holdout_months=0)
feat_service_final = flib.build_service_features(df_service, service_trends_final)

xgb_service_final = XGBRegressor(
    n_estimators=400, max_depth=4, learning_rate=0.05,
    subsample=0.8, colsample_bytree=0.8, random_state=42,
    enable_categorical=True, tree_method="hist",
)
xgb_service_final.fit(
    feat_service_final[flib.SERVICE_FEATURE_COLS], feat_service_final[flib.SERVICE_RESID_COL]
)

# ---------------------------------------------------------------------------
# 5. Forecast next 12 months (company) with the deployed model, for sanity check
# ---------------------------------------------------------------------------
future = flib.recursive_forecast_company(xgb_company_final, company_trend_final, df_company, horizon=12)
print("\n12-month company forecast:\n", future)

future_line = flib.recursive_forecast_service_line(
    xgb_service_final, service_trends_final, df_service, "GEO / AEO (AI Search) Services", horizon=6
)
print("\n6-month GEO/AEO forecast:\n", future_line)

# ---------------------------------------------------------------------------
# 6. Persist artifacts
# ---------------------------------------------------------------------------
joblib.dump(xgb_company_final, f"{ARTIFACT_DIR}/company_model.pkl")
joblib.dump(company_trend_final, f"{ARTIFACT_DIR}/company_trend.pkl")
joblib.dump(xgb_service_final, f"{ARTIFACT_DIR}/service_model.pkl")
joblib.dump(service_trends_final, f"{ARTIFACT_DIR}/service_trends.pkl")

flib.save_json(
    {
        "company_feature_cols": flib.COMPANY_FEATURE_COLS,
        "service_feature_cols": flib.SERVICE_FEATURE_COLS,
        "holdout_months": flib.HOLDOUT_MONTHS,
        "model_comparison": comparison.to_dict(orient="index"),
        "winner_by_mape": winner,
        "service_model_metrics": service_metrics,
        "reconciliation_metrics": recon_metrics,
        "trained_through_date": str(df_company["date"].max().date()),
    },
    f"{ARTIFACT_DIR}/metrics.json",
)

print("\nSaved artifacts to", ARTIFACT_DIR)
