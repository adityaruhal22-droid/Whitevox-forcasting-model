"""
forecasting_lib.py
------------------
Shared data loading, feature engineering, training, and recursive-forecasting
utilities for the Whitevox revenue forecasting project.

Imported by both `whitevox_forecasting.ipynb` (training) and `app.py` (serving),
so the exact same feature logic is used at train time and at inference time.

MODELING DESIGN NOTE — why "trend + residual" instead of feeding XGBoost raw revenue
--------------------------------------------------------------------------------
Whitevox's revenue is a strongly, near-monotonically trending series (it roughly
quadruples over the 8.5-year history). Tree-based models like XGBoost cannot
extrapolate: a leaf's output is the mean of training targets that landed in it, so
XGBoost can never predict a value larger than what it saw during training. Fed raw
revenue, it systematically underforecasts every month beyond the training window.

The fix used throughout this module: fit a simple trend on log(revenue) vs. a time
index (this extrapolates perfectly well — it's linear regression, not a tree), then
train XGBoost only on the *residual* — how far actual revenue deviates from that
trend, driven by seasonality and lead/spend dynamics. The residual is stationary
(bounded, doesn't grow over time), which is exactly the kind of target trees handle
well. Final forecast = trend + predicted residual.
"""
from __future__ import annotations

import json
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

DATA_DIR_DEFAULT = "data"

COMPANY_LAGS = (1, 3, 6, 12)
SERVICE_LAGS = (1, 3, 6)
HOLDOUT_MONTHS = 12


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def load_company_df(data_dir: str = DATA_DIR_DEFAULT) -> pd.DataFrame:
    df = pd.read_csv(f"{data_dir}/whitevox_company_monthly_kpis.csv", parse_dates=["date"])
    return df.sort_values("date").reset_index(drop=True)


def load_service_df(data_dir: str = DATA_DIR_DEFAULT) -> pd.DataFrame:
    df = pd.read_csv(f"{data_dir}/whitevox_monthly_by_service_line.csv", parse_dates=["date"])
    df = df.sort_values(["service_line", "date"]).reset_index(drop=True)
    return df


def get_service_lines(df_service: pd.DataFrame) -> list[str]:
    return sorted(df_service["service_line"].unique().tolist())


def restrict_to_post_launch(df_service: pd.DataFrame) -> pd.DataFrame:
    """Drop the all-zero rows that precede each service line's real launch month."""
    out = []
    for line, g in df_service.groupby("service_line"):
        g = g.sort_values("date")
        first_live = g.index[g["revenue_usd"] > 0]
        if len(first_live) == 0:
            continue
        start = first_live[0]
        out.append(g.loc[start:])
    return pd.concat(out).sort_values(["service_line", "date"]).reset_index(drop=True)


# ---------------------------------------------------------------------------
# Calendar helpers
# ---------------------------------------------------------------------------
def add_calendar_features(df: pd.DataFrame, date_col: str = "date") -> pd.DataFrame:
    df = df.copy()
    df["month"] = df[date_col].dt.month
    df["quarter"] = df[date_col].dt.quarter
    df["month_sin"] = np.sin(2 * np.pi * df["month"] / 12)
    df["month_cos"] = np.cos(2 * np.pi * df["month"] / 12)
    return df


# ---------------------------------------------------------------------------
# Trend fitting (log-linear regression — extrapolates safely, unlike a tree)
# ---------------------------------------------------------------------------
def fit_trend(t_index: np.ndarray, revenue: np.ndarray) -> LinearRegression:
    """Fit log1p(revenue) ~ t_index (+ t_index^2 for mild curvature)."""
    X = np.column_stack([t_index, t_index ** 2])
    y = np.log1p(revenue)
    model = LinearRegression().fit(X, y)
    return model


def predict_trend_log(model: LinearRegression, t_index: np.ndarray) -> np.ndarray:
    X = np.column_stack([t_index, t_index ** 2])
    return model.predict(X)


# ---------------------------------------------------------------------------
# COMPANY-LEVEL feature set — target: residual of log(total_revenue_usd) vs. trend
# ---------------------------------------------------------------------------
COMPANY_FEATURE_COLS = (
    [f"resid_lag_{k}" for k in COMPANY_LAGS]
    + ["resid_roll_mean_3", "resid_roll_mean_12"]
    + ["month_sin", "month_cos", "quarter"]
    + ["leads_log_lag_1", "mqls_log_lag_1", "spend_log_lag_1", "headcount"]
)
COMPANY_TARGET_COL = "total_revenue_usd"
COMPANY_RESID_COL = "resid"


def build_company_features(df_company: pd.DataFrame, trend_model: LinearRegression) -> pd.DataFrame:
    """
    Build the full feature/target frame for the company-level model.
    All residual lag/rolling features are computed with .shift(1)+ so nothing at
    time t uses information only available at or after time t (no leakage).
    Lead/MQL/spend counts are lagged by 1 month before use (they're recognized in
    the same reporting period as revenue and would otherwise leak same-month info)
    and log-transformed to tame their own scale growth.
    `headcount` is used contemporaneously: staffing levels are a planned business
    input decided ahead of time, not a byproduct of that month's revenue.
    """
    df = add_calendar_features(df_company).sort_values("date").reset_index(drop=True)
    df["t_index"] = np.arange(len(df))
    df["trend_log"] = predict_trend_log(trend_model, df["t_index"].to_numpy())
    df[COMPANY_RESID_COL] = np.log1p(df[COMPANY_TARGET_COL]) - df["trend_log"]

    for k in COMPANY_LAGS:
        df[f"resid_lag_{k}"] = df[COMPANY_RESID_COL].shift(k)
    df["resid_roll_mean_3"] = df[COMPANY_RESID_COL].shift(1).rolling(3).mean()
    df["resid_roll_mean_12"] = df[COMPANY_RESID_COL].shift(1).rolling(12).mean()

    df["leads_log_lag_1"] = np.log1p(df["total_new_leads"]).shift(1)
    df["mqls_log_lag_1"] = np.log1p(df["inbound_mqls"]).shift(1)
    df["spend_log_lag_1"] = np.log1p(df["total_marketing_spend_usd"]).shift(1)

    return df


def time_split(df: pd.DataFrame, holdout_months: int = HOLDOUT_MONTHS):
    cutoff_idx = len(df) - holdout_months
    return df.iloc[:cutoff_idx].copy(), df.iloc[cutoff_idx:].copy()


# ---------------------------------------------------------------------------
# SERVICE-LINE-LEVEL feature set — target: residual of log(revenue_usd) vs. per-line trend
# ---------------------------------------------------------------------------
SERVICE_FEATURE_COLS = (
    [f"resid_lag_{k}" for k in SERVICE_LAGS]
    + ["resid_roll_mean_3"]
    + ["month_sin", "month_cos", "quarter", "months_since_launch"]
    + ["leads_log_lag_1", "spend_log_lag_1", "service_line"]
)
SERVICE_TARGET_COL = "revenue_usd"
SERVICE_RESID_COL = "resid"


def fit_service_trends(df_service_post_launch: pd.DataFrame, holdout_months: int = HOLDOUT_MONTHS) -> dict:
    """One log-linear trend per service line, fit on that line's training portion only."""
    trends = {}
    for line, g in df_service_post_launch.groupby("service_line"):
        g = g.sort_values("date").reset_index(drop=True)
        train_g = g.iloc[: max(len(g) - holdout_months, 3)]  # keep >=3 points even for very short lines
        t = np.arange(len(train_g))
        trends[line] = fit_trend(t, train_g[SERVICE_TARGET_COL].to_numpy())
    return trends


def build_service_features(df_service: pd.DataFrame, trend_models: dict) -> pd.DataFrame:
    """
    Build the panel feature/target frame for the per-service-line model.
    Same no-leakage rules as build_company_features. `service_line` is kept as a
    pandas 'category' dtype so XGBoost can use its native categorical split
    support (enable_categorical=True at train time).
    """
    df_service = restrict_to_post_launch(df_service)
    frames = []
    for line, g in df_service.groupby("service_line"):
        g = add_calendar_features(g).sort_values("date").reset_index(drop=True)
        g["months_since_launch"] = np.arange(len(g))
        trend_log = predict_trend_log(trend_models[line], g["months_since_launch"].to_numpy())
        g[SERVICE_RESID_COL] = np.log1p(g[SERVICE_TARGET_COL]) - trend_log

        for k in SERVICE_LAGS:
            g[f"resid_lag_{k}"] = g[SERVICE_RESID_COL].shift(k)
        g["resid_roll_mean_3"] = g[SERVICE_RESID_COL].shift(1).rolling(3, min_periods=1).mean()

        g["leads_log_lag_1"] = np.log1p(g["new_leads"]).shift(1)
        g["spend_log_lag_1"] = np.log1p(g["marketing_spend_usd"]).shift(1)
        frames.append(g)

    out = pd.concat(frames).sort_values(["service_line", "date"]).reset_index(drop=True)
    out["service_line"] = out["service_line"].astype("category")

    # Cold-start lines (e.g. GEO/AEO) won't have deep lags yet on their first few
    # months — fill with each line's own expanding mean up to that point (no
    # future leakage) so those early rows are still usable instead of dropped.
    fill_cols = [c for c in out.columns if c.startswith("resid_lag_") or c.startswith("resid_roll_")]
    for col in fill_cols:
        out[col] = out.groupby("service_line", observed=True)[col].transform(
            lambda s: s.fillna(s.expanding().mean())
        )
    out[fill_cols] = out[fill_cols].fillna(0.0)
    out["leads_log_lag_1"] = out.groupby("service_line", observed=True)["leads_log_lag_1"].bfill().fillna(0.0)
    out["spend_log_lag_1"] = out.groupby("service_line", observed=True)["spend_log_lag_1"].bfill().fillna(0.0)

    return out


def time_split_panel(df: pd.DataFrame, holdout_months: int = HOLDOUT_MONTHS):
    cutoff_date = (df["date"].max() - pd.DateOffset(months=holdout_months - 1)).replace(day=1)
    train = df[df["date"] < cutoff_date].copy()
    test = df[df["date"] >= cutoff_date].copy()
    return train, test


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------
def regression_metrics(y_true, y_pred) -> dict:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    mae = float(np.mean(np.abs(y_true - y_pred)))
    rmse = float(np.sqrt(np.mean((y_true - y_pred) ** 2)))
    denom = np.where(y_true == 0, np.nan, y_true)
    mape = float(np.nanmean(np.abs((y_true - y_pred) / denom)) * 100)
    return {"MAE": round(mae, 2), "RMSE": round(rmse, 2), "MAPE_%": round(mape, 2)}


def seasonal_naive_forecast(series: pd.Series, holdout: int, season: int = 12) -> np.ndarray:
    """Forecast = value from `season` periods ago. Requires len(series) >= holdout + season."""
    return series.shift(season).iloc[-holdout:].to_numpy()


# ---------------------------------------------------------------------------
# Recursive multi-step forecasting (COMPANY level) — used by the Streamlit app
# ---------------------------------------------------------------------------
def recursive_forecast_company(
    xgb_model,
    trend_model: LinearRegression,
    df_company_raw: pd.DataFrame,
    horizon: int,
    spend_pct_change: float = 0.0,
    leads_pct_change: float = 0.0,
) -> pd.DataFrame:
    """
    Roll the trained company-level model forward `horizon` months.
    Future exogenous drivers (leads/MQLs/spend/headcount) are projected as the
    trailing-12-month average, then optionally scenario-adjusted by the user's
    requested percentage change (applied to spend and leads/MQLs).
    """
    history = df_company_raw.copy().sort_values("date").reset_index(drop=True)
    last_date = history["date"].max()
    avg_leads = history["total_new_leads"].tail(12).mean()
    avg_mqls = history["inbound_mqls"].tail(12).mean()
    avg_spend = history["total_marketing_spend_usd"].tail(12).mean()
    last_headcount = history["headcount"].iloc[-1]

    work = history.copy()
    future_rows = []

    for step in range(1, horizon + 1):
        next_date = (last_date + pd.DateOffset(months=step)).replace(day=1)
        row = {
            "date": next_date,
            "total_new_leads": avg_leads * (1 + leads_pct_change / 100),
            "inbound_mqls": avg_mqls * (1 + leads_pct_change / 100),
            "total_marketing_spend_usd": avg_spend * (1 + spend_pct_change / 100),
            "headcount": last_headcount,
            COMPANY_TARGET_COL: np.nan,  # placeholder; filled in below
        }
        work = pd.concat([work, pd.DataFrame([row])], ignore_index=True)

        t_index = np.arange(len(work))
        trend_log_next = predict_trend_log(trend_model, t_index)[-1]

        # Temporarily fill the NaN target with the trend-implied value so lag/
        # rolling computations over the residual series don't propagate NaN;
        # it gets overwritten by the model's actual prediction two lines down.
        work.loc[work.index[-1], COMPANY_TARGET_COL] = np.expm1(trend_log_next)
        feats = build_company_features(work, trend_model)
        x_last = feats.iloc[[-1]][COMPANY_FEATURE_COLS]
        resid_pred = float(xgb_model.predict(x_last)[0])

        pred_revenue = max(float(np.expm1(trend_log_next + resid_pred)), 0.0)
        work.loc[work.index[-1], COMPANY_TARGET_COL] = pred_revenue

        future_rows.append({"date": next_date, "forecast_revenue_usd": pred_revenue})

    return pd.DataFrame(future_rows)


# ---------------------------------------------------------------------------
# Recursive multi-step forecasting (SERVICE-LINE level) — used by the Streamlit app
# ---------------------------------------------------------------------------
def recursive_forecast_service_line(
    xgb_model,
    trend_models: dict,
    df_service_raw: pd.DataFrame,
    service_line: str,
    horizon: int,
    spend_pct_change: float = 0.0,
    leads_pct_change: float = 0.0,
) -> pd.DataFrame:
    line_hist = df_service_raw[df_service_raw["service_line"] == service_line].copy()
    line_hist = line_hist[line_hist["revenue_usd"] > 0].sort_values("date").reset_index(drop=True)
    if line_hist.empty or service_line not in trend_models:
        return pd.DataFrame(columns=["date", "forecast_revenue_usd"])

    trend_model = trend_models[service_line]
    last_date = line_hist["date"].max()
    avg_leads = line_hist["new_leads"].tail(12).mean()
    avg_spend = line_hist["marketing_spend_usd"].tail(12).mean()
    avg_deal = line_hist["avg_deal_size_usd"].tail(12).mean()

    work = line_hist.copy()
    future_rows = []

    for step in range(1, horizon + 1):
        next_date = (last_date + pd.DateOffset(months=step)).replace(day=1)
        months_since_launch_next = len(work)  # 0-indexed continuation
        trend_log_next = predict_trend_log(trend_model, np.array([months_since_launch_next]))[0]

        row = {
            "date": next_date,
            "service_line": service_line,
            "new_leads": avg_leads * (1 + leads_pct_change / 100),
            "marketing_spend_usd": avg_spend * (1 + spend_pct_change / 100),
            "avg_deal_size_usd": avg_deal,
            "revenue_usd": np.expm1(trend_log_next),  # placeholder, overwritten below
            "active_clients": work["active_clients"].iloc[-1],
            "new_clients": work["new_clients"].tail(12).mean(),
            "churned_clients": work["churned_clients"].tail(12).mean(),
            "projects_completed": work["projects_completed"].tail(12).mean(),
        }
        work = pd.concat([work, pd.DataFrame([row])], ignore_index=True)

        feat_full = build_service_features(work, trend_models)
        x_last = feat_full[
            (feat_full["service_line"] == service_line) & (feat_full["date"] == next_date)
        ].iloc[[-1]][SERVICE_FEATURE_COLS]
        x_last["service_line"] = x_last["service_line"].astype("category")

        resid_pred = float(xgb_model.predict(x_last)[0])
        pred_revenue = max(float(np.expm1(trend_log_next + resid_pred)), 0.0)
        work.loc[work.index[-1], "revenue_usd"] = pred_revenue

        future_rows.append({"date": next_date, "forecast_revenue_usd": pred_revenue})

    return pd.DataFrame(future_rows)


# ---------------------------------------------------------------------------
# Misc
# ---------------------------------------------------------------------------
def save_json(obj: dict, path: str):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=str)


def load_json(path: str) -> dict:
    with open(path) as f:
        return json.load(f)
