# Whitevox Revenue Forecasting — Notebook + Streamlit App

Forecasts Whitevox's monthly revenue (company-wide and per service line) from the
synthetic dataset, and deploys the result as an interactive Streamlit app.

## Files

```
whitevox_forecast/
├── data/
│   ├── whitevox_company_monthly_kpis.csv
│   └── whitevox_monthly_by_service_line.csv
├── forecasting_lib.py            # shared feature engineering + modeling code
├── whitevox_forecasting.ipynb    # EDA, model comparison, training, evaluation (pre-run, with outputs)
├── train_and_evaluate.py         # same pipeline as the notebook, as a plain script
├── app.py                        # Streamlit app — loads artifacts, does NOT retrain
├── artifacts/                    # produced by the notebook; loaded by app.py
│   ├── company_model.pkl
│   ├── company_trend.pkl
│   ├── service_model.pkl
│   ├── service_trends.pkl
│   └── metrics.json
└── requirements.txt
```

## How to run

```bash
pip install -r requirements.txt

# 1. (Re)generate the model artifacts — only needed once, or after changing the data/features
jupyter nbconvert --to notebook --execute --inplace whitevox_forecasting.ipynb
# — or, equivalently, run the plain script:
python train_and_evaluate.py

# 2. Launch the app
streamlit run app.py
```

Both the notebook and `app.py` import `forecasting_lib.py`, so feature logic is
never duplicated between training and serving.

## Modeling approach (short version)

Whitevox's revenue is a strongly trending series. XGBoost fed raw revenue
**systematically underforecasts** because tree models can't extrapolate beyond
values seen in training. The fix: fit a simple log-linear trend with plain
regression (which extrapolates fine), and have XGBoost predict only the
**residual** around that trend — a bounded, stationary target trees are good at.
Final forecast = trend + predicted residual. Full reasoning and the "before"
numbers are in Section 2 of the notebook.

Three approaches were compared on a strict 12-month, time-based holdout:

| Model | Holdout MAPE |
|---|---|
| Seasonal naive | ~12% |
| **SARIMAX** | **~3%** (best pure accuracy) |
| XGBoost (trend + residual) | ~6% |

**SARIMAX wins on accuracy**, but **XGBoost is what's deployed** in `app.py`,
because the app needs to answer "what if we change spend/leads?" — a scenario
input SARIMAX (as configured, without exogenous regressors) can't take. This is
a deliberate accuracy-vs-capability trade-off; if scenario planning weren't a
requirement, SARIMAX would be the better default.

A **per-service-line XGBoost model** (10 lines, one categorical feature) was also
built so the app can forecast any single line, including the short-history
GEO/AEO line. Summing its forecasts reconciles closely to the independently
modeled company total — a useful sanity check.

## Known limitations (worth knowing before treating this as more than a demo)

- **Data is synthetic.** Leads and marketing spend were generated as
  *consequences* of revenue in the synthetic dataset, not causes of it — so the
  app's spend/leads scenario sliders move the forecast only modestly. On real
  operating data, where spend and leads genuinely lead revenue, the same
  mechanism should show a stronger effect.
- **Future exogenous inputs (leads/spend/headcount) are projected as a trailing
  12-month average**, not sourced from an actual sales/marketing plan. Swap in
  real planned figures if you have them.
- **Prediction intervals for the company view** are a simple ±1.28×(holdout
  residual std) band (an approximate 80% interval), not a fully calibrated
  quantile model. Per-service-line forecasts don't yet have an interval.
- **Cold-start lines** (e.g., GEO/AEO, live since March 2024) have a trend fit
  on limited history — treat their longer-horizon forecasts with extra caution.

## Deploying to Streamlit Community Cloud

1. Push this folder to a GitHub repo (include `data/` and pre-generated `artifacts/`,
   or add a build step that runs the notebook/script before `streamlit run`).
2. On share.streamlit.io, point at `app.py` with `requirements.txt` in the same repo.
3. No secrets or API keys are required — everything runs on the bundled CSVs and
   pre-trained artifacts.
